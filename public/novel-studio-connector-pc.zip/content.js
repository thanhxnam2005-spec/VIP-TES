(function() {
  'use strict';
  let sent = false;
  let lastContentHash = '';

  const cleanText = (text) => {
    return (text || '')
      .replace(/[\u200B\u200C\u200D\uFEFF]/g, '')
      .replace(/@Bạn đang đọc bản lưu trong hệ thống/g, '')
      .replace(/Bạn đang xem văn bản gốc chưa dịch, có thể kéo xuống cuối trang để chọn bản dịch\./g, '')
      .replace(/Đang tải nội dung chương\.\.\./g, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  };

  const doExtract = () => {
    const isFanqie = location.href.includes('fanqienovel.com');
    if (isFanqie) {
      const box = document.querySelector('.muye-reader-content');
      if (!box) return '';
      const clone = box.cloneNode(true);
      clone.querySelectorAll("script, style, .bottom-ad, iframe, .nav, .footer").forEach(el => el.remove());
      let html = clone.innerHTML.replace(/<br\s*\/?>/gi, '\n').replace(/<p[^>]*>/gi, '\n').replace(/<\/p>/gi, '\n');
      const temp = document.createElement('div');
      temp.innerHTML = html;
      return cleanText(temp.textContent);
    }
    const box = document.querySelector('#content-container .contentbox');
    if (!box) return '';
    const inner = cleanText(box.innerText);
    let obf = '';
    box.querySelectorAll('i').forEach(el => {
      if ((el.id && el.id.startsWith('ran')) || el.id?.startsWith('exran') || el.hasAttribute('h') || el.hasAttribute('t') || el.hasAttribute('v')) {
        obf += el.textContent;
      }
    });
    obf = cleanText(obf);
    return obf.length > inner.length ? obf : inner;
  };

  const sendToBackground = (content) => {
    if (sent || content.length < 200) return;
    sent = true;
    lastContentHash = content.substring(0, 100);
    const title = (document.title || '').split(/\s+-\s+/)[0]?.trim() || '';
    chrome.runtime.sendMessage({
      type: "STV_CONTENT_READY",
      content,
      title,
      url: location.href,
      length: content.length
    });
  };

  const clickNextChapter = () => {
    const isFanqie = location.href.includes('fanqienovel.com');
    if (isFanqie) {
      // Fanqie might use div, a, or button for next chapter.
      const fanqieNext = document.querySelector('.page-next, .muye-reader-next, .reader-next') || 
        Array.from(document.querySelectorAll('a, div, button, span')).find(el => {
            const txt = el.textContent || '';
            return txt.includes('下一章') || txt.includes('下一页') || txt.toLowerCase().includes('chương sau') || txt.toLowerCase().includes('trang tiếp');
        });
      if (fanqieNext) {
        console.log('[STV] Found Fanqie next button, clicking it:', fanqieNext);
        sent = false; // Reset sent flag so we can extract the next chapter
        fanqieNext.click();
        return true;
      }
      console.log('[STV] ERROR: Fanqie next button not found!');
      return false;
    }
    const links = document.querySelectorAll('a');
    for (const a of links) {
      const text = (a.textContent || '').trim();
      if (text.includes('Chương sau')) {
        sent = false;
        a.click();
        return true;
      }
    }
    return false;
  };

  const autoExtract = () => {
    const content = doExtract();
    if (content.length > 200) {
      // If we already sent this exact content, don't send again
      if (sent && lastContentHash === content.substring(0, 100)) return;
      console.log('[STV] autoExtract found content, sending to background');
      sendToBackground(content);
    }
  };

  // Observe DOM changes to auto-extract when SPA navigates
  const observer = new MutationObserver(() => {
     if (!sent) {
        setTimeout(autoExtract, 1000);
     }
  });
  observer.observe(document.body, { childList: true, subtree: true });

  const startPolling = () => {
    for (let i = 0; i < 15; i++) {
      setTimeout(autoExtract, 1500 + i * 1000);
    }
  };
  startPolling();

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "EXTRACT_NOW") {
      console.log('[STV] Received EXTRACT_NOW');
      sent = false;
      const tryExtract = (n) => {
        if (n <= 0) {
          console.log('[STV] EXTRACT_NOW failed after retries');
          sendResponse({ content: '', length: 0 });
          return;
        }
        const content = doExtract();
        if (content.length > 200) {
          console.log('[STV] EXTRACT_NOW success');
          const title = (document.title || '').split(/\s+-\s+/)[0]?.trim() || '';
          sendResponse({ content, title, length: content.length, url: location.href });
        } else {
          setTimeout(() => tryExtract(n - 1), 1000);
        }
      };
      setTimeout(() => tryExtract(12), 1500);
      return true;
    }
    if (msg.type === "GO_NEXT") {
      console.log('[STV] Received GO_NEXT');
      const ok = clickNextChapter();
      sendResponse({ ok });
      return false;
    }
  });

  chrome.runtime.sendMessage({ type: "STV_PAGE_LOADED", url: location.href });
})();